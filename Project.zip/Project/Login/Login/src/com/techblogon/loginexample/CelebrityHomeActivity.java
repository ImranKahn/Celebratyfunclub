package com.techblogon.loginexample;


import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CelebrityHomeActivity extends Activity 
{
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
	     super.onCreate(savedInstanceState);
	     setContentView(R.layout.celebrity_home_activity);
	     
	     WebView webView=(WebView)findViewById(R.id.webView1);
	        webView.loadUrl("file:///android_asset/www/index.html");
	    
	     
	     
	     
	}
}
