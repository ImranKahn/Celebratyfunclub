package com.techblogon.loginexample;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends Activity 
{
	Button loginButton;
	LoginDataBaseAdapter loginDataBaseAdapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
	     super.onCreate(savedInstanceState);
	     setContentView(R.layout.login);
	     // create a instance of SQLite Database
	     loginDataBaseAdapter=new LoginDataBaseAdapter(this);
	     loginDataBaseAdapter=loginDataBaseAdapter.open();
	     
	     loginButton=(Button) findViewById(R.id.buttonSignIn);
	     final  EditText editTextUserName=(EditText)findViewById(R.id.editTextUserNameToLogin);
		   final  EditText editTextPassword=(EditText)findViewById(R.id.editTextPasswordToLogin);
	     
	     loginButton.setOnClickListener(new View.OnClickListener() {
				
				public void onClick(View v) {
					// get The User name and Password
					String userName=editTextUserName.getText().toString();
					String password=editTextPassword.getText().toString();
					
					// fetch the Password form database for respective user name
					String storedPassword=loginDataBaseAdapter.getSinlgeEntry(userName);
					
					// check if the Stored password matches with  Password entered by user
					if(password.equals(storedPassword))
					{
						//call another celebrity home activity
						
			
						Intent intent=new Intent(getApplicationContext(),CelebrityHomeActivity.class);
						startActivity(intent);
						//show the login message
						
						//Toast.makeText(HomeActivity.this, "Congrats: Login Successfull", Toast.LENGTH_LONG).show();
						//dialog.dismiss();
					}
					else
					{
						Toast.makeText(LoginActivity.this, "User Name or Password does not match", Toast.LENGTH_LONG).show();
					}
				}
			});
	}
	     @Override
	 	protected void onDestroy() {
	 		super.onDestroy();
	 	    // Close The Database
	 		loginDataBaseAdapter.close();
	 	}
	     
}
